#-*- coding: utf-8 -*-
'''
################
#  Crea una funcion para elegir a los individuos
#  de una población, utilizando los siguientes elementos
#      depth = debe ser al menos de 5
#      maxnumNodos = 2 ^ depth
#      tot_pob = (maxnumNodos / 2) -1
#  Se generar individuos hasta la cantidad máxima de población
#  (Tot_pob)
#       efim = debe ser entre -5 a + 5      (Efimero)
#       conj_fun = ['+',  '-', '*', 'Div']  (Funciones)
#       term_fun=[2,   2,   2,   2] (Cantidad de terminos X Fun)
#       conj_ter = ['x', 'efim']        (Terminos para las Fun)
#       cont_fun = 1
#       cont_argf = 0       #Este se debe incrementar al elegir una función
#       cont_nod = 0         #No indica la posición en la lista
# Inició: 30/May/2019
# Actualizacion:
#         31/Mayo/2019 :Módulo genera individuo
#           05/Jun/2019  :El módulo generó fuciones incorrectas.
#           06/Jun/2019  :Módulo corregido y funcionando.
#           07/Jun/2019  :Se adapto para funcionar con la mutacion.
#           09/Jun/2019  :Se analiza situacion con funciones con 1 argumento.
#           10/Jun/2019  :Se adecuo para generar los elementos restantes para la mutación.
#         3/Jun/2019   :Módulo interpretador de prefijos.
#           05/Jun/2019  :Generó resultados inesperados con el módulo evaluar_gener
#           06/Jun/2019  :Módulo corregido y funcionando.
#         4/Jun/2019   :CreaXY construye la lista de valores para x, y.
#         6/Jun/2019   :gene_cero, crea la generacion CERO de N_Individuos.
#         6/Jun/2019   :evaluar_gener, recibe una generación y optiene las aptitudes
#         6/Jun/2019   :selc_torneo, selecciona para cada individuo de la genera, un contrincante, y eleige al mejor.
#           13/Jun/2019  :Se detectaron incongruencia en la asignacion.
#           14/Jun/2019  :Se rastreo y se corrigio el problema.
#         7/Jun/2019   :muta_genera, elige individuos que podran mutar.
#           08/Jun/2019  :Se adecuo el módulo para identificar terminales y funciones.
#           09/Jun/2019  :Se implementaron mejoras y regresa una generación.
#           10/Jun/2019  :Se adecuo para localizar los subarboles y sus limites y mutar al raíz.
#           11/Jun/2019  :El módulo presentó problemas en conjunto con genera indviduo, realizarón adecuaciones.
#           12/Jun/2019  :Se analizó e identificó la problematica.
#           17/Jun/2019  :Se adaptaron segementos para verificar al individuo antes de terminar.
#           18/Jun/2019  :Se probaron los segmentos, se adecuaron.
#         15/Jun/2019  :verif_indiv, verifica la construccion correcta de un individuo.
#           16/Jun/2019  :Se detectaron inconcistencia en funciones de la Mutacion.
#           17/Jun/2019  :Se diseñaron segmentos al modulo de mutacion para verficar al individuo al final.
#         19/Jun/2019  :Se inicia el diseño del modulo de cruza.
#         20/Jun/2019  :munos_resul integra todos los modulos y guarda los resultados en un CSV.
#           21/Jun/2019  :Se detectaron inconsistencias en los resultados obtenidos.
#         20/Ago/2019  :Se retoma la construcción de la cruza.
#         25/Sept/2019 :Se agrega a cruza la funcion de intercambio de funciones
#           26/Sept/2019: Se realizan pruebas
#         24/Agos/2020 :Se cambia la forma de Mejor Aptitud para usar 5 aptitudes
#         25/Ago/2020  :Crear Regrecion lineal para determinar la primera mejor funcion
#                       y los rangos de efimeros.
###############
'''

import random
import math
import time

## Valores a cambiar antes de iniciar la ejecucióon
#Datos para prueba Individuos por generacion 20
#Numero de generaciones 10

    #Numero de individuos para la generacion 0, 50
    #Se probo con 50 Marzo 2022
indiv_genera = 50
    #Número de generaciones 100; cambiar 10 o 20 por 100
    #Se probo con 100 Feb 2024
num_genera = 100
#num_genera = 10
    #Profundidad de los árboles 2^6, 64 nodos, 2^7 128 nodos
    #Se probo 6 Mar 2022
depth = 6
    #Se definen los conjuntos para las Funcinoes, y Terminales
#conj_fun = ['+', '-', '*', 'Div', 'raiz', 'expn', 'seno', 'logn']
conj_fun = ['+', '-', '*', 'Div', 'seno', 'logn']
term_fun = [2, 2, 2, 2, 1, 1]
conj_term = ['efim', 'x']
efimero = 0
    #Lugar donde se encuentra el archivo con los valores x y, en este formato (espacios)
rutArch = 'C:/MUNOS/Conjunto.txt'
rutArch2 = 'C:/MUNOS/Final.csv'
    #Para Linux
#rutArch = '/home/ccd/proypg/Conjunto.txt'
#rutArch2 = '/home/ccd/proypg/Final.csv'

    # Linux LeoAtrox
#rutArch = '/home/fbelmont/proypg/Conjunto.txt'
#rutaARch2 = '/home/fbelmont/proypg/Final.csv'

## Solo los valores anteriores


#El maximo numero de nodos por individuo.
#Para la mutación sera un porcentaje
#maxnumNodos = 12
maxnumNodos = 2 ** depth
#La poblacion máxima, necesaria para limitar el balance de los árboles 
tot_pob = round((maxnumNodos / 2) -1)
#Se utilizará para la mutacion en genera_Indiv para definir el numero máximo de funciones
factor = 0.5
#//No será necesario cambio Define la probabilidad de mutación (1/ un % de acuerdo No Individuos por Gen)
#//No será necesario cambió que se toma de (10 numero de indivXGener (10 * 0.25 es el % de probnMuta
#porc_indivgen = (indiv_genera * 0.25)
#prob_mut = (1 / porc_indivgen)
#La probabilidad de muta será directamente el % deseado del 25% al 100%
#prob_mut = 0.25
prob_mut = 0.50
#prob_mut = 0.60
#La probabilidad de cruza estriba entre 25% al 100% anterior 90%
#De una poblacion de 50 individuos y con el 100% hace 25 cruzas, es en parejas
#prob_cruz = 0.91
prob_cruz = 0.51
#prob_cruz = 0.61
individ  = []
#Numero maximo de aptitudes van de 1 a 5
#Se probo de 1 a 4 Julio 2024
#Se probo de 6 a 10 Ene 2025
#num_maxap = 5
num_maxap = 9
#Define la funcion de la regresión lineal en la generacion 0
funlineal = ''
#Define el rango del efimero
#efim_max = round(abs(b1), 3)
efim_max = 3
#efim_min= round(0.001, 4)
efim_min = 0.01



#Crea aleatoriamente una función o terminal como parte del individuo
def genera_elemento(tipo_elem, efimero):
     if tipo_elem < 0.5 :
          pos_ind = random.randint(0,(len(conj_fun)-1))
          elem_indiv = conj_fun[pos_ind]
     else:
          pos_ind = random.randint(0,(len(conj_term)-1))
          elem_indiv = conj_term[pos_ind]
          if elem_indiv == 'efim' :
               elem_indiv = efimero

     return elem_indiv

def genera_individuo(hay_nod):
    individ = []
    tipo = 0
    cont_fun = 0         #Es 0 cuando la generacion es 0, elimine cn_fun
    cont_argf = 1        #Es 1 para iniciar el proceso
    cont_nod = 0         #Es 0 en generacion 0, en otro caso es !=
    pob_tot = 0
    nod_rest = 0
    nod_neces = 0


    #Estables la cantidad de funciones máximas por individuo
    if hay_nod > 0 :
         #print('###_ No es generación CERO _##')
         #pob_tot = es 4   (0.5 * 7)
         pob_tot = round((tot_pob * factor))
         cont_fun = 1
         if hay_nod >= (maxnumNodos - 3) :
              pob_tot = 0
    else:
         pob_tot = tot_pob
    
    #print('\n### Total de Poblacion ###', str(tot_pob))
     #El maxnumNodos es 16 deph =4 ** 2
    while cont_nod < maxnumNodos and cont_argf > 0 :
         # and cont_fun < tot_pob

        efimero = random.uniform(efim_min, efim_max)
        #Controlar el máximo numero de funciones
        nod_rest = maxnumNodos - cont_nod
        #print('Elelento en pos '+str(cont_nod)+' ',end=' ')
        #Establece el primer nodo como función
        if cont_nod == 0 :
             tipo = 0
             nuevo = genera_elemento(tipo,efimero)
             cont_argf = term_fun[conj_fun.index(nuevo)]
             cont_nod = hay_nod
             cont_fun = cont_fun + 1
             #print(str(nuevo)+'Funcion Argumts: '+str(cont_argf))
        else:
             #Define entre función o una terminal
             tipo = random.uniform(0,1)
             if tipo < 0.5 and cont_fun < pob_tot and nod_neces < nod_rest :
                  nuevo = genera_elemento(tipo,efimero)
                  cont_argf = (cont_argf + term_fun[conj_fun.index(nuevo)]) - 1
                  cont_fun = cont_fun + 1
                  nod_neces = (cont_fun * 2) - 1
                  #print(str(nuevo)+'No. Funcion : '+str(cont_fun))
             else:
                  tipo = 1
                  nuevo = genera_elemento(tipo,efimero)
                  cont_argf = cont_argf - 1
                  #print(str(nuevo)+' Argumts: '+str(cont_argf))
               
        if cont_nod < maxnumNodos:
            individ.append(nuevo)

        cont_nod = cont_nod + 1

    return individ

def evaluar_op(operacion):
     
     def operacion_suma(oper1, oper2):
          return (oper1 + oper2)
     def operacion_resta(oper1, oper2):
          return (oper1 - oper2)
     def operacion_multip(oper1, oper2):
          return (oper1 * oper2)
     def operacion_division(oper1, oper2):
          if oper2 != 0:
               return (oper1 / oper2)
          else:
               return 0
     def operacion_seno(oper1):
          #print('Valor de Seno', oper1,'\n')
          if oper1 == float('inf') or oper1 == float('-inf'):
               return 10000
          else:
               return math.sin(oper1)
          
     def operacion_raiz(oper1):
          return (math.sqrt(math.fabs(oper1)))
     def operacion_expn(oper1):
          #print("exponente ", oper1)
          if oper1 >= 709:
               return 10000
          else:
               return math.exp(oper1)
     def operacion_logn(oper1):
          #print("Logaritmo ",oper1)
          if oper1 <= 0 :
               return 10000
          else:
               return math.log(abs(oper1))
          
     
     operacion_func = {'+': operacion_suma,
                       '-': operacion_resta,
                       '*': operacion_multip,
                       'Div': operacion_division,
                       'seno': operacion_seno,
                       'raiz': operacion_raiz,
                       'expn': operacion_expn,
                       'logn': operacion_logn}
     return operacion_func[operacion]


#Interpeta version 2     
def interpreta_prefijo (funcion, valx):
     expres = []
     desconec_fun = ''
     con_pos = 0
     pos_fun = -1
     no_operact = 0
     cont_operan = 0
     operiz1 = -1
     operd2 = -1
     der=0
     izq=0
     func = ''
     elemento = ''
     no_opert = 0
     result_temp = 0
     
     
     #expres = genera_individuo
     desconec_fun = list(funcion)
     expres = desconec_fun
     
     #print("interpreta >", expres)
     while len(expres) > 1:
          #print('Cont Posicion ',str(con_pos),' Elemento ', elemento,end=' ')
          elemento = expres[con_pos]
          
          if elemento in conj_fun:
               no_opert = int(term_fun[conj_fun.index(elemento)])
               #print('No operandos ', str(no_opert))
               if pos_fun == -1 :
                    pos_fun = con_pos
                    no_operact = no_opert
               else:
                    pos_fun = con_pos
                    no_operact = no_opert
                    if operiz1 > 0 :
                         #operaniz1 = -1 13/Jun/2019
                         operiz1 = -1
                         cont_operan = 0
          else:
               cont_operan = cont_operan + 1
                                   
               if cont_operan == 1 :
                    operiz1 = con_pos
                    #print('En Operando Izq')
                    if cont_operan == no_operact :
                         if expres[operiz1] == 'x' :
                              izq = valx
                         else:
                              izq = expres[operiz1]
                         expres.pop(operiz1)
                         
                         func = expres[pos_fun]
                         result_temp = evaluar_op(func)(izq)
                         expres[pos_fun] = result_temp
                         #print('Solucion \n', str(izq),' ',func,' = ', str(result_temp))
                         pos_fun = -1
                         no_operact = 0
                         operiz1 = -1
                         cont_operan = 0
                         con_pos = -1
               if cont_operan == 2 :
                    operd2 = con_pos
                    #print('En Operando Der')
                    if cont_operan == no_operact :
                         if expres[operiz1] == 'x' :
                              izq = valx
                         else:
                              izq = expres[operiz1]
                         if expres[operd2] == 'x' :
                              der = valx
                         else:
                              der = expres[operd2]
                         expres.pop(operd2)
                         expres.pop(operiz1)
                         
                         func = expres[pos_fun]
                         result_temp = evaluar_op(func)(izq, der)
                         #print('Solucion \n', str(izq),' ',func,' ', str(der),' = ', str(result_temp))
                         expres[pos_fun]=result_temp
                         pos_fun = -1
                         no_operact = 0
                         #operaniz1 = -1  13/Jun/2019
                         operiz1 = -1
                         #operand2 = -1  13/Jun/2019
                         operd2 = -1
                         cont_operan = 0
                         con_pos = -1
               

          con_pos = con_pos + 1 
     #Fin While 
     
     return expres[0]

def crearxy (opc):
     ruta = rutArch
     datos = []
     
     archivo = open(ruta,'r')
     linea = archivo.readline()
     
     while linea != '' :
          #Elimina basura
          lista=linea.replace('\n','').split('\t')

          if opc == 'x' :
               #construye las listas x
               datos.append(lista[0])
          else:
               #construye las listas y
               datos.append(lista[1])

          linea = archivo.readline()

     archivo.close()
     return datos

#Genera aleatoriamente un numero de individuos para la generacion Cero
def gene_cero(indiv, valx, valy):
     #Define el numero de individuos por generación
     num_indiv = indiv
     #Lista de individuos de la generacion CERO
     gen_cer = []
     funcion = ''
     funlineal = ''
     hay_nodo = 0
     reslin = 0
     temp = ''
     
     
     #Se manda llamar genera_individuo tantos individuos sehan ncesarios
     cont_indiv = 1
     while cont_indiv <= num_indiv :
          if cont_indiv == 1:
              #Obtiene la funcion de la regresión lineal
              #Crea la primera función aleatoria
              funlineal = reg_lineal(valx, valy)
              #Modifica la funcion de la regresion lineal  22/Abr/22
              #Se evalua la funion
              reslin = interpreta_prefijo(funlineal, float(valx[0]))
              #Obtiene el faltente o sobrante para igualar a cero
              reslin = reslin - float(valy[0])
              #Modifica la funcion linenal    22/Abr/22
              funlineal= ['+'] + funlineal[0:]
              funlineal.append(float(reslin))
              
              funcion = funlineal
          else:
               funcion = genera_individuo(hay_nodo)
          
          #print('Evaluando a: ',cont_indiv)
          #print(funcion)
          temp = verif_indiv(funcion)
          gen_cer.append(funcion)

          cont_indiv = cont_indiv + 1

     return gen_cer

#Evalua la aptitud para la generación que se le proporcione
def evaluar_gener(gneracion, dtsx, dtsy):
     #Establece los individuos a evaluar en la generación
     gener_eval = list(gneracion)
     #Función a evaluar
     funcion = ''
     #Se obtienen los valores de 'X' y de 'Y'
     datx = list(dtsx)
     daty = list(dtsy)
     #Establecer la longitud de valores a evaluar 'X'
     longi_datx = len(datx)
     #Valores de aptitud
     aptitud = 0
     aptituef = 0
     prom_aptid = 0
     abs_apt = 0
     tods_prom = []
     #Contadore de valores 'x' evaluados
     contx_eval = 0

     #Recorre la generación hasta el último y los evalua con todos los 'X', si existe
     cont_indiv = 0
     #print('##_ Inicia a evaluar Funcion _##')
     while cont_indiv < len(gener_eval) :
          prom_aptid = 0
          aptituef = 0
          #Identificar al individuo a evaluar
          funcion = gener_eval[cont_indiv]
          #print('Individuo: ',cont_indiv,' -> ',funcion,end=' ')
          #print('Individuo: ',cont_indiv,' -> ',funcion)
          funcion = verif_indiv(funcion)
          
          if 'x' in funcion :
               #Inicia los contadores para recorrer los valores de 'X'
               conx_eval = 0
               #print('###_ X _### ',datx[conx_eval])
               #print('X {0:2d} -> {1:2d}'.format(cont_eval, datx[conx_eval]))
               while conx_eval < longi_datx :
                    #Calcula la aptitud de la funcion
                    aptitud = 0
                    aptitud = interpreta_prefijo(funcion,float(datx[conx_eval]))
                    aptitud = math.fabs(float(daty[conx_eval]) - aptitud)
                    
                    #print('X- '+str(datx[conx_eval])+' Aptid.- '+str(aptitud))
                    #print('X {0:2d} - {1:.2f} -> {2:.4f}'.format(conx_eval, float(datx[conx_eval]), float(aptitud)))
                    
                    prom_aptid = float (prom_aptid) + aptitud
                    conx_eval = conx_eval + 1

               #La siguiente linea que calcula el promedio estaba comentada 12/Abr/2022
               prom_aptid = prom_aptid / longi_datx
               abs_apt = math.fabs(float(prom_aptid))
               #print('Promedio .- '+str(abs_apt))
          else:
               #Modificar para integrar a la variable independiente
               #y castigar al promedio 2/Julio
               conx_eval = 0
               aptituef = interpreta_prefijo(funcion,0)
               while conx_eval < longi_datx :
                    aptitud = 0
                    aptitud = math.fabs(float(daty[conx_eval]) - aptituef)
                    
                    prom_aptid = float (prom_aptid) + aptitud + 9
                    conx_eval = conx_eval + 1

               #La siguiente linea que calcula el promedio estaba comentada 12/Abr/2022
               #prom_aptid = prom_aptid / longi_datx
               prom_aptid = prom_aptid / longi_datx
               abs_apt = math.fabs(float(prom_aptid))
               
               #print('Promedio .- '+str(abs_apt))
          
          #print('{0:3d} -> {1:.6f} : {2:}'.format(cont_indiv,float(abs_apt),str(funcion)))
          tods_prom.append(abs_apt)
          #print('Promedio: ',abs_apt)
          cont_indiv = cont_indiv + 1

     return tods_prom

#Regresion lineal
def reg_lineal(datx, daty):
     tot_dat = len(datx)
     prom_x = 0
     prom_y = 0
     cont_dat = 0
     xi_promx = 0
     yi_promy = 0
     sum_xiyi = 0
     sum_xipxcua = 0
     b1 = 0
     b0 = 0
     fun =[]

     #Obtiene el promedio de x y de y
     while cont_dat < tot_dat -1 :
          #print(prom_x," ", datx[cont_dat])
          prom_x = prom_x + float(datx[cont_dat])
          prom_y = prom_y + float(daty[cont_dat])
          cont_dat = cont_dat + 1
          
     prom_x = prom_x / tot_dat
     prom_y = prom_y / tot_dat

     #Se obtienen la sumatorias para la regresion
     cont_dat = 0
     while cont_dat < tot_dat - 1:
          xi_promx = float(datx[cont_dat]) - prom_x
          yi_promy = float(daty[cont_dat]) - prom_y
          sum_xiyi = sum_xiyi + (xi_promx * yi_promy)
          sum_xipxcua = sum_xipxcua + (xi_promx ** 2)
          cont_dat = cont_dat + 1
     
     #Calcula los elementos b1 y bo de la regresion
     b1 = sum_xiyi / sum_xipxcua
     b1 = round(b1,3)
     b0 = prom_y - (b1 * prom_x)
     b0 = round(b0,3)
     #print( sum_xipxcua)
     #Cambia el valor de los efimeros
     #efim_min = round((abs(b1)* - 1), 3)
     #Define los rangos para generar los efimeros
     #efim_min = round(0.001, 4)
     #efim_max = round(abs(b1), 3)
     
     #Construye la función
     fun = ['+', b0,'*', b1, 'x']

     return fun

#Seleccion de la funciones de una generación de mejor aptitud
def selec_torneo(Gene, Apt):
     cont_indices = 0
     cont_incomp = 0
     funs_actuales = list(Gene)
     apt_actuales = list(Apt)
     tot_indiv = (len(funs_actuales) - 1)
     indi_alea = []
     valapt_act = 0
     valapt_com = 0
     funs_ganador = []
     apt_ganador = []
     
     #Genera los indices para la comparacion para cada aptitud actual
     #print('.... Inicia seleccion por Torneo  ....')
     while cont_indices <= tot_indiv :
          indi_alea.append(random.randint(0, tot_indiv))
          #print(cont_indices,' ',indi_alea[cont_indices])
          cont_indices = cont_indices + 1

     #print('##_ Construye funciones ganadoras _##')
     cont_indices = 0
     while cont_indices <= tot_indiv :
          valapt_act = apt_actuales[cont_indices]
          cont_incom = indi_alea[cont_indices]
          valapt_com = apt_actuales[cont_incom]

          #print('Compiten ', valapt_act, ' vs ', valapt_com,'!',funs_actuales[cont_indices],end=' ')
          #print('{0:d} - {1:.6f} vs {2:d} - {3:.6f} : {4:}'.format(cont_indices,
          #     float(valapt_act), cont_incom, float(valapt_com),funs_actuales[cont_indices]))
          if valapt_act <= valapt_com :
               funs_ganador.append(funs_actuales[cont_indices])
               apt_ganador.append(apt_actuales[cont_indices])
               #print(' Gana ',valapt_act)
          else:
               funs_ganador.append(funs_actuales[cont_incom])
               apt_ganador.append(apt_actuales[cont_incom])
               #print(' Gana ', valapt_com)

          cont_indices = cont_indices + 1
               
     return funs_ganador

def verif_indiv(fun):
     #Verifica la construccion del nuevo individuo
     arg_falta = 0
     tot_nod = 0
     nvo_func = list(fun)
     cont_nod = ''
     element = ''
     temp = ''
     efim = random.uniform(efim_min, efim_max)

     for cont_nod in nvo_func :
          if (cont_nod in conj_fun) :
               if arg_falta == 0 :
                    arg_falta = arg_falta + term_fun[conj_fun.index(cont_nod)]
               else:
                    arg_falta = arg_falta + term_fun[conj_fun.index(cont_nod)] - 1
          else:
               arg_falta = arg_falta - 1
     #Se dio un caso de que le faltaron argumentos, per ya eran 16 nodos 
     if arg_falta > 0 :
          print('Revisión general Falta ', arg_falta,' Argumentos')
          print(nvo_func)
          while len(nvo_func) <= maxnumNodos and arg_falta > 0:
                element = genera_elemento(1, efim)
                nvo_func.append(element)
                
                arg_falta = arg_falta - 1
          
         # print('Funcion final: ', nvo_func)
                         
     if arg_falta < 0 :
          print('La revision identifico Mas Arg que fun ', arg_falta)
          print(nvo_func)
          
          tot_nod = len(nvo_func) - 1
          temp = nvo_func
          pos = tot_nod
          continua = True
          print(pos)
          
          while (arg_falta < 0 and continua) :
               
               if not(nvo_func[pos] in conj_fun):
                    temp = temp[0:pos]
                    arg_falta = arg_falta + 1
                    pos = pos - 1
                    print("arg_falt: ", arg_falta)
                    
               if arg_falta == 0 :
                    continua = False
               
          nvo_func = temp
          
          print(nvo_func)
          time.sleep(10)
      
     return nvo_func

def aleatorio() :
     #Genera numeros aleatorios fraccionarios entre 0 y 1
     num = 0
     num = random.uniform(0,1)

     return num

def nva_term (indiv, pmtn, efim):
     element = indiv[pmtn]
     while indiv[pmtn] == element :
          element = genera_elemento(1,efim)
     otra_fun = camb_term(indiv, pmtn, element)
     
     return otra_fun

def muta_genera (gene):
     otra_gen = list(gene)
     indiv_gen = len(otra_gen)
     cont_indiv = 0
     cont_nod = 0
     arg_falt = 0
     cont_arg = 0
     arg_econ = 0
     fun_act = ''
     nod_enfun = 0
     punt_muta = 0
     #pm1 = 0
     pd1 = 0
     pd2 = 0
     pi2 = 0
     aux = ''
     elemento = ''
     ranprob_mut = 0
     ran_tipo = 0
     efime = 0
     tipo_dat = 0
     nva_func = ''
     nvo_indiv = ''
     nva_gen = []
     
     #print('__ Principia Mutacion __')
     while cont_indiv < indiv_gen :
          #Elegir a un individuo de la generación
          fun_act = list(otra_gen[cont_indiv])
          nod_enfun = (len(fun_act) - 1)
          cont_arg = 1
          arg_econ = 0
          #Indica si el individuo se mutará probmut es < 0.25 % o el 100% > 1
          #ranprob_mut = 0.19
          #ranprob_mut = 0.15  #Mutara
          ranprob_mut = aleatorio()
          aux = ''
          nva_func = ''
          nvo_indiv = ''
          elemento = ''
          cont_nod = 0
          punt_muta = 0
          tipo_dat = 0
          ran_tipo = 0
          arg_falt = 0
          efime = 0
          pi2 = 0
          pd2 = 0
          pd1 = 0

          #print('Total Individuos en generacion: ', indiv_gen)
          #print('Se verificará si se muta', end=' ')
          #Verifica si el individuo se mutará
          #print('{0:3d} :: {1:}\n'.format(cont_indiv, fun_act))
          if ranprob_mut < prob_mut :
               #print('Si se mutara [',cont_indiv,"] ", str(ranprob_mut))
               #Genera un aleatorio entre 0 y la cantidad de nodos de la
               #función para encontrar el punto de mutación
               #punt_muta = 10 #Elige una terminal
               #punt_muta = 6 #Elige una funcion
               punt_muta = punto_cruza(fun_act)
               
               
               #Se genera la probabilidad de lo que será creado terminal o funcion
               #ran_tipo = 0.6  #Genera terminal
               #ran_tipo = 0.4  #Genera Funcion
               ran_tipo = aleatorio()
               
               #print('Verifica que se mutará.. ', end=' ')
               #Identifica lo que se mutara una funcion o treminal
               #print('Pmut ', punt_muta, '\nSe muta: ',fun_act)
               tipo_dat = tip_dato(fun_act, punt_muta)
               #print('Punto Muta',punt_muta,'\t Tipo dato ',tipo_dat)
               
               efime = random.uniform(efim_min, efim_max)
               
               #Verifica el intercambio entre terminales
               if tipo_dat == 1 and ran_tipo >= 0.5 :
                    nva_func = nva_term(fun_act, punt_muta, efime)
                    
               #Verifica el intercambio entre terminal y funcion
               if tipo_dat == 1 and ran_tipo <  0.5 :
                    nvo_indiv = genera_individuo(0)
                    #print("\nNuevo Individuo \n",nvo_indiv)
                    pd2 = bus_pcd (nvo_indiv,pi2)
                    nva_func = fun_enter(fun_act,punt_muta,nvo_indiv,pi2,pd2)
               
               #Verifica el intercambio entre función y terminal
               if tipo_dat == 2 and ran_tipo >= 0.5 :
                    #Verifica si se encuentra en la raiz genera un nuevo individuo
                    if punt_muta == 0 :
                         nva_func = genera_individuo(0)
                    else:
                         pd1 = bus_pcd (fun_act, punt_muta)
                         elemento = genera_elemento(1, efime)
                         nva_func = ter_enfun(fun_act,punt_muta,pd1,elemento)
               
               #Verifica el intercambio entre funcion y funcion
               if tipo_dat == 2 and ran_tipo < 0.5 :
                    nvo_indiv = genera_individuo(0)
                    #print("\nNuevo Individuo \n",nvo_indiv)
                    pd1 = bus_pcd(fun_act, punt_muta)
                    pd2 = bus_pcd(nvo_indiv, pi2)
                    nva_func = fun_enfun(fun_act,punt_muta,pd1,nvo_indiv,pi2,pd2)
               
               #print('Nueva Funcion ', nva_func)
               
                    
               #Verifica la construccion del nuevo individuo
               #print("\n\nVerifica la construcción del individuo")
               arg_falt = 0
               for cont_nod in nva_func :
                    if (cont_nod in conj_fun) :
                         if arg_falt == 0 :
                              arg_falt = arg_falt + term_fun[conj_fun.index(cont_nod)]
                         else:
                              arg_falt = arg_falt + term_fun[conj_fun.index(cont_nod)] - 1
                    else:
                         arg_falt = arg_falt - 1
                              
               #print('En Terminales Faltan.. ', arg_falt)
                                   
               if arg_falt > 0 :
                    print('Ter->Arb Falto argumento ',arg_falt,' Pm1 ',pm1,' Pm2 ', pm2)
                    while len(nva_func) <= maxnumNodos and arg_falt > 0:
                         elemento = genera_elemento(1, efime)
                         nva_func.append(elemento)
                         arg_falt = arg_falt - 1
               if arg_falt < 0 :
                    print('Ter->Arb sobran Arg ', arg_falt)
                              
                    #print(nvo_indiv,'\nInd..#')
                    
          else:
               nva_func = fun_act
               
          #Verifica nuevamente la función     
          #nva_func = verif_indiv(nva_func)
          
          #print('{0:3d} Por: {1:}'.format(cont_indiv, nva_func))
          #print('Tamaño: ',len(nva_func))
          nva_gen.append(nva_func)
          cont_indiv = cont_indiv + 1
          
     return nva_gen


#Determina los 5 indice de mejor aptitud de la generación 21/Abr/22
def mejor_apt (aptid, genact, mjind_act):
     list_aptit= list(aptid)
     ind_mejap = []
     numer_indiv = (len(aptid) - 1)
     pos_mejap = 0
     cont_ind = 1
      
     while cont_ind <= num_maxap :
          cont_ap = pos_mejap + 1
                       
          #buscar merjor apitud
          while cont_ap <= numer_indiv :
            if list_aptit[cont_ap] < list_aptit[pos_mejap] :
                #Selecciona al mejor
                if len(ind_mejap) == 0:
                    pos_mejap = cont_ap
                else:
                    if not(cont_ap in ind_mejap) and not(genact[cont_ap] in mjind_act) :
                          pos_mejap = cont_ap
            cont_ap = cont_ap + 1
            
          ind_mejap.append(pos_mejap)
          #Verifica apartir de que posicion iniciara hacer comparaciones
          #Inicia des del 0 si no esta en los indices 
          pos_mejap = b_sigapt(ind_mejap)
          cont_ind = cont_ind + 1
          
     return ind_mejap

#Busca la siguiente posicion de aptitud
def b_sigapt(indices):
    pos_apt = 0
    encont = True
    
    while encont :
         if (pos_apt in indices) :
              pos_apt = pos_apt + 1
         else:
               encont = False
     
    return pos_apt

#Determina el indice del individuo con la peor aptitud de la generación
def peor_apt (aptid):
     list_aptit= list(aptid)
     ind_perap = []
     numer_indiv = (len(aptid) - 1)
     pos_peor = 0
     cont_ind = 1

     while cont_ind <= num_maxap :
          cont_ap = pos_peor + 1
          
          #buscar peor apitud
          while cont_ap <= numer_indiv :
               if list_aptit[cont_ap] > list_aptit[pos_peor] :
                    #Selecciona la peor aptitud
                    if len(ind_perap) == 0:
                         pos_peor = cont_ap
                    else:
                         if not(cont_ap in ind_perap):
                              pos_peor = cont_ap
               
               cont_ap = cont_ap + 1
          
          ind_perap.append(pos_peor)
          pos_peor = b_sigapt(ind_perap)
          cont_ind = cont_ind + 1

     return ind_perap

#Identifica punto de cruza
def punto_cruza(indiv):
     otro_indiv = list(indiv)
     nod_enfun = 0
     pun_cruza = 0
     
     nod_enfun = (len(otro_indiv) - 1)
     #print(otro_indiv)
     pun_cruza = random.randint(0, nod_enfun)
     
     return pun_cruza

#Identifica del tipo de dato en el punto de cruza
def tip_dato(indiv,pcin):
     tpelem = 0
     
     if not (indiv[pcin] in conj_fun) :
          tpelem = 1
          #print("Se encontro Terminal")
     else:
          tpelem = 2
          #print("Se encontro Funcion")
     
     return tpelem

#Coloca en un individuo la terminal de cambio
def camb_term(indiv,pcin,term):
     nvo_indiv = list(indiv)
     nvo_indiv[pcin] = term
     #print("Nuevo individuo .. ",nvo_indiv)
     
     return nvo_indiv

#Ajustar el punto de cruce a una funcion siguiente
def ajus_pc(indiv,pcn):
     nvo_pc = 0
     continua = True
     tam_indiv = len(indiv) - 1
     nvo_pc = pcn

     #Recorre los nodos del individuo
     while nvo_pc < tam_indiv and continua :
          nvo_pc = nvo_pc + 1
          #print(indiv,"Nvo_pc ",nvo_pc);
          
          #Verifica si la nueva posicio es una funcion
          if indiv[nvo_pc] in conj_fun :
               continua = False

     #print("Nueva poscion de cruce .. ",nvo_pc)
     
     return nvo_pc

#Establece el Punto de Cruza Derecho PCD
def bus_pcd(indiv,pcn):
     pcd = pcn + 1
     tot_nod = len(indiv) - 1
     func = indiv[pcn]
     tot_arg = term_fun[conj_fun.index(func)]
     continua = True
     #print("Encontro funcion", func," Con ", tot_arg," argumentos")
     
     
     while pcd <= tot_nod and continua :
          #Actualiza la funcion encontrada
          func = indiv[pcd]
          
          #Si el individuo es una terminal
          if not(func in conj_fun) :
               tot_arg = tot_arg - 1
          else:
               tot_arg = tot_arg + (term_fun[conj_fun.index(func)] - 1)
          if tot_arg == 0 :
               continua = False
          pcd = pcd + 1
          
     #print("Punto de cruza Derecho.. ", pcd - 1)
     
     return (pcd - 1)

#Construye auxiliar elminando la funcion del individuo y colocando la terminal
def ter_enfun(indiv,pcin,pcdn,term):
     aux = ''
     tot_nod = len(indiv) - 1
     aux = indiv[0:pcin]
     aux.append(term)
     
     #Si el punto de cruza derecho es menor al total de nodos pasa el resto de nodos
     if pcdn < tot_nod :
          aux = aux + indiv[pcdn+1:]
     #print("La terminal substituye funcion.. \n",aux)
     
     return aux

#Coloca el punto de cruce PCIn en la ultima funcion del individuo
def ult_fun(indiv):
     tam_indiv = len(indiv)
     cont_nod = tam_indiv - 1
     continua = True

     #Se coloca en la posicion de la ultima funcion
     while cont_nod > 0 and continua:
          if indiv[cont_nod] in conj_fun :
               continua = False
               
          cont_nod = cont_nod - 1
     
     #Verifica que el contador de nodos sea > 0
     if cont_nod > 0 :
          cont_nod = cont_nod + 1
     
     #print("Contador nodos en ult-fun ", cont_nod,"\n")
     return cont_nod

#Construlle individuo colocando una funcion en una terminal
def camb_fun(indn,pin,fun):
     tot_nod = len(indn) - 1
     temp = ''
     
     #Trasfiere los nodos del individuo desde la posicion 0 hasta antes del Punto de cruza
     temp = indn[0:pin]
     #Agrega la secuencia de la funcion
     temp = temp + fun
     if pin < tot_nod :
          temp = temp + indn[pin+1:]
     
     return temp

#Construlle individuo colocando una funcion o terminal en la posicion de una terminal
def fun_enter(indv2,pzi2,indv1,pzi1,pzd1):
     tam_indiv = len(indv2)
     aux = ''
     cont_prub = 1
     tam_ideal = False
     fun_camb = ''
     tam_fun = 0
     tam_tot = 0
     npzi1 = pzi1
     npzd1 = pzd1
     #Cambiar 11 por maxnumNodos
     max_nodos = maxnumNodos
     
     #Determina si la funcion del individuo 1 corresponde al tamanio del individuo 2
     while cont_prub <= 2 and tam_ideal == False :
          fun_camb = indv1[npzi1:npzd1+1]
          tam_fun = len(fun_camb)
          tam_tot = tam_fun + tam_indiv - 1
          
          #Si el tamanio total excede al maximo de nodos busca la ultima funcion en indv1
          if tam_tot > max_nodos and cont_prub < 2 :
               npzi1 = ult_fun(indv1)
               if npzi1 > 0 :
                    npzd1 = bus_pcd(indv1,npzi1)
                    #print("Nuevo PCi> ",npzi1, "Nuevo PCd> ", npzd1)
          
          if tam_tot <= max_nodos :
               tam_ideal = True
          
          cont_prub = cont_prub + 1
     
     #Si el tamanio excede el maximo se cambiara por una terminal del individuo1
     if tam_ideal == False :
          #print('Se excedio el tamanio')
          npzi1 = npzi1 + 1
          
          #Buscara la posicion de una terminal en el individuo1
          while npzi1 <= max_nodos and indv1[npzi1] in conj_fun :
               npzi1 = npzi1 + 1
          
          #Si esta en una terminal se substituye este con la terminal del individuo2
          if not(indv1[npzi1] in conj_fun) :
               aux = camb_term(indv2,pzi2,indv1[npzi1])
               #print('Se cambio por terminal.. ',aux)
     
     #Se cambia una terminal por una funcion
     if tam_ideal :
          #print("La funcion a cambiar")
          #print(fun_camb)
          aux = camb_fun(indv2,pzi2,fun_camb)
          
     
     return aux

#Modulo que construlle un nuevo indivuo intercambiando funciones
def camb_funs(indn, pin, pdn, fun):
     tot_nod = len(indn) - 1
     temp = ''
     
     #Transfiere los nodos hasta antes del punto de cruza
     temp = indn[0:pin]
     #Coloca la nueva funcion
     temp = temp + fun
     #Transfiere el resto de nodos
     if pdn < tot_nod :
          temp = temp + indn[pdn+1:]
     
     return  temp

#Modulo que construlle el nuevo individuo cambiando una fucion por otra
def fun_enfun(indv1, pzi1, pzd1, indv2, pzi2, pzd2):
     tam_indiv1 = len(indv1)
     tam_indiv2 = len(indv2)
     aux = ''
     cont_prub = 1
     tam_ideal = False
     npzi1 = pzi1
     npzd1 = pzd1
     npzi2 = pzi2
     npzd2 = pzd2
     fun_cam1 = indv1[npzi1:npzd1+1]
     fun_cam2 = ''
     tam_fun1 = len(fun_cam1)
     tam_fun2 = 0
     tam_tot = 0
     #Cambiar 11 por maxnumNodos
     max_nodos = maxnumNodos
          
     #Determina si la funcion corresponde al tamanio del individuo 1
     while cont_prub <= 2 and tam_ideal == False :
          fun_cam2 = indv2[npzi2:npzd2+1]
          tam_fun2 = len(fun_cam2)
          tam_tot = tam_fun2 + (tam_indiv1 - tam_fun1)
          
          #Si el tamanio total excede al maximo de nodos busca la ultima funcion en indv1
          if tam_tot > max_nodos and cont_prub < 2 :
               npzi2 = ult_fun(indv2)
               npzd2 = bus_pcd(indv2, npzi2)

          if tam_tot <= max_nodos :
               tam_ideal = True
          
          cont_prub = cont_prub + 1
     
     #Si el tamanio excede el maximo se cambiara por una terminal
     if tam_ideal == False :
          #print('Se excedio el tamanio')
          npzi2 = npzi2 + 1
          
          #Buscara la posicion de una terminal
          while npzi2 <= max_nodos and indv2[npzi2] in conj_fun :
               npzi2 = npzi2 + 1
          
          #Si esta en una terminal se substitulle la funcion por una terminal
          if not(indv2[npzi2] in conj_fun) :
               aux = ter_enfun(indv1,npzi1,npzd1,indv2[npzi2])
               #print('Se cambio por terminal.. ',aux)
     
     #Se cambia una terminal por una funcion
     if tam_ideal :
          aux = camb_funs(indv1,npzi1, npzd1,fun_cam2)
     
     
     return aux

#Reliza la cruza entre pares de inidividuos de una generación 20/Ago
def cruza(gene):
     otra_gen = list(gene)
     indiv_gen = (len(otra_gen) - 1)
     cont_indiv = 0
     indiv1 = ''
     indiv2 = ''
     temp1 = ''
     temp2 = ''
     pci1 = 0
     pci2 = 0
     tip1 = 0
     tip2 = 0
     pcd1 = 0
     pcd2 = 0
     prob_cruza = 0
     nva_gen = []

     #print('---  Cruza ----')
     while cont_indiv + 1 <= indiv_gen :
          tip1 = 0
          tip2 = 0
          pcd1 = 0
          pcd2 = 0
          indiv1 = list(otra_gen[cont_indiv])
          indiv2 = list(otra_gen[cont_indiv + 1])
          #print('{0:d} _ {1:}'.format(cont_indiv, indiv1),'\n')
          #print('{0:d} _ {1:}'.format(cont_indiv+1,indiv2),'\n')
          
          #Identifica el punto de cruza inicial de cada individuo
          
          pci1 = punto_cruza(indiv1)
          pci2 = punto_cruza(indiv2)
          
          #pci1 = 2
          #pci2 = 35
          #print('Punto Cruza1 > {0:2d} Punto Cruza2 > {1:2d}'.format(pci1, pci2))
          
          #Se verifica la probabilidad de cruzar los individuos que será del 90%
          prob_cruza = random.uniform(0,1)
          #print('La probabilidad es.. ',prob_cruza)
          #La probabilidad de cruza es prob_cruz = 0.91
          if prob_cruza > prob_cruz:
               #print('No se cruza')
               temp1 = indiv1
               temp2 = indiv2
               #print(temp1,'\n',temp2)
          else:
               #print('Si se cruza')
               #print('Si se cruza [',cont_indiv,']', prob_cruza)
               #Verifica que el tipo de elemento terminal=1 o funcion=2
               #print("Verifica el tipo de dato")
               tip1 = tip_dato(indiv1,pci1)
               tip2 = tip_dato(indiv2,pci2)
               
               
               #Verifica que individuo1 y 2 sean Funciones y no esten en la Raiz
               if tip1 == 2 :
                    #Cambia el punto de cruce 1 si es Raiz
                    if pci1 == 0 :
                         pci1 = ajus_pc(indiv1,pci1)
                         tip1 = tip_dato(indiv1,pci1)
               if tip2 == 2 :
                    #Canbia el punto de cruce 2 si es Rai
                    if pci2 == 0 :
                         pci2 = ajus_pc(indiv2,pci2)
                         tip2 = tip_dato(indiv2,pci2)
               
               #Verificar si individuo1 y 2 son terminales
               if tip1 == 1 and tip2 == 1 :
                    temp1 = camb_term(indiv1,pci1,indiv2[pci2])
                    temp2 = camb_term(indiv2,pci2,indiv1[pci1])
                    #print("Cambio por Termina")
                    #print(temp1,"\n",temp2,"\n\n")
               
               #Verificar individuo1 es funcion y el individuo2 es terminal
               if tip1 == 2 and tip2 == 1:
                    pcd1 = bus_pcd(indiv1,pci1)
                    temp1 = ter_enfun(indiv1,pci1,pcd1,indiv2[pci2])
                    temp2 = fun_enter(indiv2,pci2,indiv1,pci1,pcd1)
                    #print("Cambio la funcion por terminal")
                    #print(temp1)
                    #print("Cambia la terminal por funcion")
                    #print(temp2,"\n\n")
                    
                    
               #Verifica individuo1 es Terminal y el individuo2 es funcion
               if tip1 == 1 and tip2 == 2:
                    pcd2 = bus_pcd(indiv2,pci2)
                    temp1 = fun_enter(indiv1,pci1,indiv2,pci2,pcd2)
                    temp2 = ter_enfun(indiv2,pci2,pcd2,indiv1[pci1])
                    #print("Cambio la terminal por una funcion")
                    #print(temp1)
                    #print("Coloca la funcion en una terminal")
                    #print(temp2,"\n\n")
                    
               
               #Verifica individuo1 y el individuo2 son funciones
               if tip1 == 2 and tip2 ==2:
                    pcd1 = bus_pcd(indiv1,pci1)
                    pcd2 = bus_pcd(indiv2,pci2)
                    temp1 = fun_enfun(indiv1,pci1,pcd1,indiv2,pci2,pcd2)
                    temp2 = fun_enfun(indiv2,pci2,pcd2,indiv1,pci1,pcd1)
                    #print("Cambio de funciones")
                    #print(temp1,"\n",temp2,"\n\n")

          #Verifica el individuo 1, y 2
          temp1 = verif_indiv(temp1)
          temp2 = verif_indiv(temp2)
               
          nva_gen.append(temp1)
          nva_gen.append(temp2)
          temp1 = ''
          temp2 = ''
          cont_indiv = cont_indiv + 2
     
     if cont_indiv == indiv_gen :
          nva_gen.append(otra_gen[cont_indiv])
     
     #print("\n<=======>\n\n\n")
     return nva_gen


#Determina si existe alguna aptitud menor  18/Abr/2022
#Al de la regresion lineal
def log_mejapt (aptid, alogra):
     list_aptit= list(aptid)
     numer_indiv = (len(aptid) - 1)
     pos_mejap = 0
     encontrar = True

     #busca si en las apitudes hay al guna menor a la regresion
     #si la encuentra cambia encontrar a False para que ya no siga buscando
     while pos_mejap <= numer_indiv and encontrar :
          if list_aptit[pos_mejap] <= alogra :
             encontrar = False
          else:
              pos_mejap = pos_mejap + 1
      
     return encontrar

#Control de la Programacion Genetica
#Ultima modificacion  19/04/22
def pg_simp (valx, valy, logmej_apt):
  #Cuando desde munos_resul se envian los datos x, y, generacion
  #def pg_simp (valx, valy, gene):
     gene_act = ''
     apts_act = ''
     gene_selc = ''
     gene_sig = ''
     gene_sig1 = ''
     maxnum_gene = num_genera
     cont_gen = 1
     mejindv_act = []
     mejapt_act  = []
     indi_mejrap = []
     perapt_act = 0
     indi_perap = []
     long_indiv = 0
     datsx = list(valx)
     datsy = list(valy)
     enbusca = True

     #Se obtienen los valores de 'X' y de 'Y'
     #datsx = crearxy('x')
     #datsy = crearxy('y')
     
     #Muestra los valores del archivo, de las variables x, y
     #print('<<-- Valores a Probar -->> \n No. datos', len(datsx))
     #for i in range( (len(datsx)) ) :
     #     print('{0:.2f} {1:.2f}'.format(float(datsx[i]), float(datsy[i]) ))

     #Asigna las funciones a la generacion para pruebas
     #gene_act = gene
     #Crea la generacion cero para proceso normal
     gene_act = gene_cero(indiv_genera, datsx, datsy)
     #Se evalua la generacion 0, para obtener la aptitud a mejorar 18/Abr/2022
       #apts_act = evaluar_gener(gene_act, datsx, datsy)
     #Obtener la mejor aptitud de la generación a partir de la Regrecion lineal
     #El dato esta en la primera función de la generacion 0 18/Abr/2022
       #logmej_apt = apts_act[0] - 0.024
     
     #Inlcuyo el valor a comparar para detenerse con la mejor aptitud 16/abr/22
     #Mientras no se llege a la maxima generación y enbusca sea Verdadero 16/Abr/22
     while cont_gen <= maxnum_gene and enbusca:
          #>>> Evalua la aptitud <<<
          #print('\nGeneracion \t <__',cont_gen,'__>')
          apts_act = evaluar_gener(gene_act, datsx, datsy)
          long_indiv = len(gene_act)
          #Para pruebas pero va antes del While
          #gene_act = gene_cero(indiv_genera)
          
          #Muestra la generacion >> y sus aptitudes
          #print('Generacion \t <__',cont_gen,'__>')
          
          #Muejatra la mejor aptitud a Lograr 16/Abr/2022
          #print('La Mejor Aptitud a lograr: {0:0.5f}'.format(float(logmej_apt)))
          
          #Mostrar a los individuos de la generación
          #for i in range (0, long_indiv) :
               #ok print('{0:2d} >> {1:10} -> {2:6,f}'.format(i, str(gene_act[i]), float(apts_act[i]) ))
                #print('{0:2d} > {1:10}'.format(i, str(gene_act[i]) ))
          
          #Mostrará los valores de x
          #for i in range(0, len(datsx)) :
               #print('{0:2d} >> {1:.3f} - {2:.3f}'.format(i, float(datsx[i]), float(datsy[i]) ))
          
          #Muestra el promedio de aptitudes de cada individuo
          #for i in range (0, long_indiv):
          #     print('{0:2d} - {1:.2f} -> {2:}'.format(i,float(apts_act[i]), str(gene_act[i]) ))
          
          if cont_gen > 1 :
               #Busca al peor evaluado de la generación actual
               indi_perap = peor_apt(apts_act)
               #Coloca al de mejor aptitud de la generación anterior por el peor del actual
               #print('.. Asigna a peor evaluados ..')
               apts_act = tras_datgen(apts_act, indi_perap, mejapt_act)
               gene_act = tras_datgen(gene_act, indi_perap, mejindv_act)
               
          #Indentifica la posición de las 5 mejores aptitud
          indi_mejrap = mejor_apt(apts_act, gene_act, mejindv_act)
          #Traslada los 5 mejoeres individuos y aptitudes de acuerdo a los indices
          mejindv_act = dat_segind(gene_act,indi_mejrap)
          mejapt_act = dat_segind(apts_act, indi_mejrap)
          
          #Muestra la genereció actual ya con la mutación despues de la generacion 1
          #for i in range(0, long_indiv) :
          #     print('{0:2d} - {1:.6f} {2:10}'.format(i, float(apts_act[i]),str(gene_act[i]) ))
          
          #print('\n// Mejor indice actual : {0:3d} - {1:} -> {2:.6f}'.format(indi_mejrap, str(mejindv_act), float(mejapt_act)))

          #Inclur la comparacion de la logmej_apt contra la mejor aptitud  16/Abr/2022
          #Para continuar 18/Abr/2022
          enbusca = log_mejapt(mejapt_act, logmej_apt)
          if enbusca == False :
             print("##** SE ENCONTRO AL MEJOR en la generacion**## ", cont_gen)
          else:
             ### Proceso para la siguiente generación ###
             if cont_gen < maxnum_gene :
                  #// Selecciona a los mejores individuos por torneo //
                  #print('... Selección por toneo ...')
                  gene_selc = selec_torneo(gene_act, apts_act)
                  #for i in range(0, long_indiv) :
                      #print( repr(i).rjust(2),' -',repr(gene_act[i]).rjust(6),' -',repr(apts_act[i]).rjust(6))
                      #print('{0:2d} {1:10}'.format(i, str(gene_selc[i]) ))

                  #print('\n\n');
               
                  #//Cruza un % de la poblacion de la generacion seleccionada//
                  #print('=== Cruza ===');
                  gene_sig1 = cruza(gene_selc)
                     #print('== Pase Cruza ==')
                  #for i in range(0, long_indiv) :
                  #    print('{0:2d} > {1:10}'.format(i, str(gene_sig[i]) ))
               
                  #print('\n\n');
               
                  #// Muta un % de la población de la generación seleccionada //
                  #print('** Mutación **')
                  gene_sig = muta_genera(gene_sig1)
                  #print('** Pase Mutación **')
                  #for i in range(0, long_indiv) :
                       #print('{0:2d} {1:10}'.format(i, str(gene_sig1[i]) ))
                     
                  #Establece los valores para la siguiente generación
                  gene_act = ''
                  gene_selc = ''
                  gene_act = gene_sig
                  gene_sig = ''
                  gene_sig1 = ''
          
          #print('// Mejor indice: {0:10} -> {1:0.6f}'.format(str(mejindv_act), float(mejapt_act)))
          cont_gen = cont_gen + 1
     
     #Muestra las max_indiv con mejor aptitud
     #for i in range (0, len(mejindv_act)):
          #print('\n// PGMej {0:2d}: {1:10} -> {2:0.6f}'.format(i, str(mejindv_act[i]), float(mejapt_act[i])))
     
     #print(indi_mejrap)
     
     return mejindv_act

#Translada datos a la Generacion Actual
def tras_datgen(dat_ac, indi_ver, dat_tras):
     dat_fin = dat_ac
     cantid = len(indi_ver) - 1
     cont_ind = 0
     dat_ind = 0

     while cont_ind <= cantid :
          val_ind = indi_ver[cont_ind]
          dat_fin[val_ind] = dat_tras[cont_ind]
          cont_ind = cont_ind + len(indi_ver)

     return dat_fin

#Obtiene individuos con mejor aptitud
def dat_segind(gene, indi):
     dat_enind = []
     cantid = len(indi) - 1
     cont_ind = 0
     
     #Translada individuos segun los mejores indices
     while cont_ind <= cantid :
          valor_indi = indi[cont_ind]
          dat_enind.append (gene[valor_indi])
          
          cont_ind = cont_ind + 1
     
     return dat_enind

#Busca de todas las generaciones entre las 5 funciones a la mejor evaluada
def bus_mejfun(funs, val_x, val_y, flin):
     tot_funs = len(funs) - 1
     cont_funs = 0
     temp_apt = 0
     abs_apt = 0
     mej_apt = 0
     mej_ind = 0
     
     while cont_funs <= tot_funs :
          temp_apt = interpreta_prefijo(funs[cont_funs], float(val_x))
          #Esta línea se substituyo
          #abs_apt = math.fabs(temp_apt)
          #Esta linea se mofico para obtener la mejor aptitud 13/Abr/2022
          abs_apt = math.fabs(float(val_y) - temp_apt)
          
          if cont_funs == 0 :
               mej_ind = cont_funs
               mej_apt = abs_apt
          else:
               if abs_apt < mej_apt :
                    mej_ind = cont_funs
                    mej_apt = abs_apt
          
          cont_funs = cont_funs + 1

     #Determina si la funcion encontrada    19/Abr/22
     #fue el de la regresion lineal y si fue la cambia
     if flin == funs[mej_ind] :
         mej_ind = mej_ind - 1;
         if mej_ind < 0 :
             print('Indece < 0')
             mej_ind = mej_ind + 2
         print('Cambio la fun lineal : {0:} \n  por: {1:}'.format(str(flin), str(funs[mej_ind])))

     #print('\n// Mejor {0:2d}: {1:10} -> {2:0.6f}'.format(mej_ind, str(funs[mej_ind]), float(mej_apt)))     
     return funs[mej_ind]

#Convierte la funcino a texto para ser guardado  11/Abr/2022
def conv_funatext(lafun):
    fun_fin = ''
    
    for i in range(len(lafun)):
           fun_fin = fun_fin +' '+ str(lafun[i])
    #print('\nLa funcion convertida ', la_fun)

    return fun_fin

def obten_reglin(tmpx, tmpy, fun_lin):
    otr_fun = ''
    apt_lin = 0
    txt_lin = ''

    #Calcular la aptitud de la reg lineal, con el dato fuera
    apt_lin = interpreta_prefijo(fun_lin, float(tmpx))
    #Convierte la función a texto
    otr_fun = conv_funatext(fun_lin)
    #Guarda los datos en el archivo
    txt_lin = '%0.2f, %0.2f, %0.6f, %s\n'%(float(tmpx), float(tmpy), float(apt_lin), otr_fun)

    return txt_lin

#Obtiene la aptitud a mejorar con respecto a la regrecion lineal 19/Abr/2022
def lin_amejor(dtx, dty, flin):
    lfun = []
    res_fun = []
    res_fin = 0

    #Coloca la funcion dentro de la lista a evaluar  19/Abr/22
    lfun.append(flin)
    #Evalua la funcion lineal y regresa su promedio de aptitud en una lista
    res_fun = evaluar_gener(lfun, dtx, dty)
    #Establece el valor de aptitud a mejorar en la Programacion Genetica
    res_fin = res_fun[0] - 0.024

    return res_fin


#Control de toda la aplicacion y guarda informacion en el archivo Final.csv
#Ultima modificacion 19/04/22
def munos_resul():
 #Cuando se necesita recibir desde fuera gene, dtx, dty
 #def munos_resul(gene, dtx, dty):
     ruta = rutArch2
     archivo = open(ruta,'a')
     linea = ''
     fun_lin = ''
     hora= ''
     dat_x = ''
     dat_y = ''
     nva_datx = []
     nva_daty = []
     temp_x = 0
     temp_y = 0
     nva_apt = 0
     mej_funs = []
     nva_fun = ''
     otr_fun = ''
     apt_lin = 0
     cont_dat = 0
     tot_dat = 0
     tdat_nva = 0
     apt_amejor = 0
     
     
     #Se obtienen los valores de 'X' y de 'Y'
     #dat_x = [3, 4.5, 5]
     #dat_y = [2.2, 5.6, 6.6]
     #Cuando se reciben los valores fuera de la funcion
     #dat_x = dtx
     #dat_y = dty
     dat_x = crearxy('x')
     dat_y = crearxy('y')

     
     #funs= [['Div', 0.8973511419663041, 4.3513707485713],
     #       ['-', 'x', '+', 'x', -1.7299000888824212],
     #       ['seno', 'Div', 'seno', 'seno', '-', -1.8553322702063522, 3.396579865863872, 'Div', '+', 'x', 'x', 'x']
     #     ]
     
     nva_datx = dat_x[cont_dat + 1:]
     nva_daty = dat_y[cont_dat + 1:]
     #nva_datx = dat_x
     #nva_daty = dat_y
     
     tot_dat = len(dat_x)
     tdat_nva = len(nva_datx)
     
     hora = time.strftime("%H:%M:%S")+'\n'
     archivo.write(hora)
     
     while cont_dat < tot_dat :
     #while cont_dat < 2 :
     #if True :
          temp_x = dat_x[cont_dat]
          temp_y = dat_y[cont_dat]
          otr_fun = ''

            #Obtener la funcion de la regresion lineal 16/Abr/2022
            #fun_lin = reg_lineal(nva_datx, nva_daty)
            #Establece la Mejor Aptitud a lograr obtenida de la Reg Lineal
            #16/Abr/2022
            #logmej_apt = interpreta_prefijo(fun_lin, float(temp_x))

          #Obtener la funcion de la regresion lineal  19/Abr/22
          fun_lin = reg_lineal(nva_datx, nva_daty)
           #print('La funcion lineal : {0:}'.format(str(fun_lin)) )          
          #Obtiene el texto de la funcion de la regresion lineal 11/04/22
          #linea = obten_reglin(temp_x,temp_y, fun_lin)
          #archivo.write(linea)

          #Obtiene la aptitud a mejorar de acuerdo a la regresion lineal 19/04/22
          apt_amejor = lin_amejor(nva_datx, nva_daty, fun_lin)
          
          otr_fun = ''
          linea = ''
          #Llama evaluar gene con x y menos 1
          #Evalua con la mejor función la aptitud de temp_x y_temp_y
          #nva_fun = funs[cont_dat]
           #nva_fun = pg_simp(nva_datx, nva_daty, gene)
           #mej_funs = pg_simp(nva_datx, nva_daty, gene)
           
          #Llama a la Programacion Genetica y genera las mejores 5 funciones
          print('\n<< Procesando el dato...> [', cont_dat, ']')
          mej_funs = pg_simp(nva_datx, nva_daty, apt_amejor)
                    
          #print('... Se obtuvo la mejor función ..')
          #print ('El mejor de las generaciones: ',nva_fun)
          #print (nva_fun,'<x> ',float(temp_x))
          
          #Se evalua la función obtenida para el valor de x fuera
          nva_fun = bus_mejfun(mej_funs,float(temp_x), float(temp_y), fun_lin)

          nva_apt = interpreta_prefijo(nva_fun,float(temp_x))
          nva_apt = math.fabs(float(nva_apt))
          
          #print ('Aptitud :',nva_apt)
          #Convierte la funcino a texto para ser guardado
          otr_fun = conv_funatext(nva_fun)
          
          #Se insertan los datos temporales en la posicion actual
          if cont_dat < tdat_nva :
               nva_datx[cont_dat]=temp_x
               nva_daty[cont_dat]=temp_y
               
               
          #Guarda los datos en el archivo
          linea = '%0.2f, %0.2f, %0.6f, %s\n'%(float(temp_x), float(temp_y), float(nva_apt), otr_fun)
          archivo.write(linea)
               
          cont_dat = cont_dat + 1
          #print(nva_fun,' - ', nva_apt,'\n')
          #print('Funcion ',nva_fun,'\n en x ', temp_x,'\nAptitud ',nva_apt)
     hora = time.strftime("%H:%M:%S")+'\n'
     archivo.write(hora)

     archivo.close()
     
     return 0
