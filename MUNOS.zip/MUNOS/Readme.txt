Read me

#######
## Customize before starting
#######

It is recommended to place the files in the following path: C:\MUNOS

The Excel file contains the original data.
The Conjunto.txt file contains the Excel data for the program.
The Final.csv file will contain the results and functions obtained.

#######
## For customizing the code before execution
#######
If the file path is different, the code must be modified in lines 86 and 87.

To define the number of individuals per generation, line 68 should be modified.

To specify the number of generations, line 71 needs to be modified.

To indicate the operations to be used, lines 78 and 79 need to be modified.

To indicate the number of best results,line 122 needs to be modified.

#######
## Run the application from Python on Windows 
#######
   It is recommended to place the files in the following path: C:\MUNOS
   Python is started: Python
   In Python, load the file and module: from munos_win_v6 import munos_resul
   The module is executed: munos_resul()
   When finished, close Python: exit();

